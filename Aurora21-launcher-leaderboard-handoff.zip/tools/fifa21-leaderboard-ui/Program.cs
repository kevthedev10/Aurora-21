using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using FrostySdk.Frostbite;
using FrostySdk.Managers;
using FrostySdk.Interfaces;

if (args.Length != 3) throw new ArgumentException("Usage: Aurora21-LeaderboardUiTool <game directory> <leaderboard manifest JSON> <output directory>");
// FMT resolves its SDK relative to the process working directory. Anchor it to the tool installation,
// after resolving caller-supplied paths so invoking from another directory remains supported.
args = args.Select(Path.GetFullPath).ToArray();
if (!File.Exists(Path.Combine(AppContext.BaseDirectory, "SDK", "FIFA21SDK.dll")))
    throw new InvalidDataException("Missing FIFA21 SDK beside the tool.");
Directory.SetCurrentDirectory(AppContext.BaseDirectory);
var manifest = JsonNode.Parse(File.ReadAllText(args[1]))!.AsObject();
if (manifest["schema"]?.GetValue<int>() != 1 || manifest["game"]?.GetValue<string>() != "FIFA21") throw new InvalidDataException("Unsupported client manifest");
var revision = manifest["revision"]!.GetValue<string>();
var canonical = (JsonObject)manifest.DeepClone(); canonical.Remove("revision");
if (Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonical.ToJsonString()))).ToLowerInvariant() != revision) throw new InvalidDataException("Manifest revision mismatch");
foreach (var (file, key) in new[] { ("FIFA21.exe", "gameExecutableSha256"), ("CardsDLL_Win64_retail.dll", "cardsLibrarySha256") })
{
    using var stream = File.OpenRead(Path.Combine(args[0], file));
    if (Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant() != manifest["profile"]![key]!.GetValue<string>()) throw new InvalidDataException($"Unsupported game file: {file}");
}
if (!new CacheManager().LoadData("FIFA21", args[0], new Logger(), false, true)) throw new InvalidDataException("Native asset index failed");
// This reviewed FIFA21 cache can omit the collector type; the legacy manager needs it to find the asset bundle.
foreach (var entry in AssetManager.Instance.EnumerateEbx().Where(e => e.Name == "core/chunkfiles/chunkfilecollector" && string.IsNullOrWhiteSpace(e.Type)))
    entry.Type = "ChunkFileCollector";
CaptionMod.Build(AssetManager.Instance, AssetManager.Instance.EnumerateCustomAssets("legacy").ToArray(), args[2], manifest);

sealed class Logger : ILogger
{
    public void Log(string text, params object[] values) { }
    public void LogWarning(string text, params object[] values) => Console.WriteLine(text);
    public void LogError(string text, params object[] values) => Console.WriteLine(text);
}
