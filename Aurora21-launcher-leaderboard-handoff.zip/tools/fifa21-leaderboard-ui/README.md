# FIFA 21 leaderboard caption generator

This Windows development tool reads the server's leaderboard UI manifest, verifies the installed game profile, and attempts to produce a localisation `.fbmod` changing only the two leaderboard caption numerals across 21 languages. It checks round-tripped database fields before exporting.

The generator was verified with Top 25 for both modes: all 21 language databases contained exactly two requested field changes and no other row or field changes. It anchors FMT's relative SDK lookup to its installation directory and resolves caller paths first. It is not a completed launcher updater: the new both-mode `.fbmod` still needs compiled-ModData and in-game verification before replacing the working Champions prototype.

Dependencies come from the separately reviewed Frostbite Modding Tool checkout (revision `67b35957725fc961e4262afb8be08e9cd1df239e`), including its built FIFA21 plugin. They are not vendored into this repository. Build with the Windows .NET SDK:

```powershell
dotnet build tools/fifa21-leaderboard-ui/Aurora21.LeaderboardUiTool.csproj -p:FmtRoot='C:\Tools\FrostbiteModdingTool'
```

The executable is written into that checkout's `FrostbiteModdingUI/bin/Debug/net7.0-windows` directory, beside its plugin and SDK. Its three arguments are the game directory, exported manifest JSON and output directory:

```powershell
& 'C:\Tools\FrostbiteModdingTool\FrostbiteModdingUI\bin\Debug\net7.0-windows\Aurora21-LeaderboardUiTool.exe' 'C:\Games\FIFA 21' 'C:\Aurora21\leaderboards.json' 'C:\Aurora21\GeneratedCaptions'
```

It only generates replacement assets; compiling ModData and integrating downloads into the shared launcher are separate work. Run against original game data, not an already edited localisation profile. It refuses mismatched game hashes, unexpected language sets or keys, and unrelated database changes.

See [the launcher handoff](../../ultimateteam/leaderboard-client-launcher.md) for the backend contract, native evidence and remaining integration steps.
