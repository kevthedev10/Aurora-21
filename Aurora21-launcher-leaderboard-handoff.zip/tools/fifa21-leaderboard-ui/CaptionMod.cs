using System.Data;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Globalization;
using FifaLibrary;
using FrostySdk;
using FrostySdk.Frostbite;
using FrostySdk.Managers;

internal static class CaptionMod
{

    internal static void Build(AssetManager manager, AssetEntry[] assets, string output, JsonObject manifest)
    {
        var edits = manifest["captions"]!.AsArray().OfType<JsonObject>().ToDictionary(e => e["stringId"]!.GetValue<string>(), e => e);
        if (edits.Count != 2 || !edits.ContainsKey("FUT_Champions_TopX_upper") || !edits.ContainsKey("FUT_SQUADBATTLE_TOP100_TAB")) throw new InvalidDataException("Unexpected caption keys");
        foreach (var edit in edits.Values)
        {
            var size = edit["top"]!.GetValue<int>();
            var minimum = edit["mode"]!.GetValue<string>() == "champions" ? 6 : 1;
            if (size < minimum || size > 200 || edit["sourceNumber"]!.GetValue<string>() != "200") throw new InvalidDataException("Invalid caption edit");
        }
        var languages = manifest["languages"]!.AsArray().Select(e => e!.GetValue<string>()).ToArray();
        if (languages.Length != 21 || languages.Distinct().Count() != 21) throw new InvalidDataException("Expected 21 unique languages");
        var reports = new List<object>();
        var entries = assets.Where(e => e.Name.StartsWith("data/loc/", StringComparison.OrdinalIgnoreCase) && e.Name.EndsWith(".db", StringComparison.OrdinalIgnoreCase)).OrderBy(e => e.Name).ToArray();
        if (!entries.Select(e => Path.GetFileNameWithoutExtension(e.Name)).Order().SequenceEqual(languages.Order()))
            throw new InvalidDataException("Manifest language set differs from installed game: " + string.Join(", ", entries.Select(e => Path.GetFileNameWithoutExtension(e.Name))));
        if (entries.Length != 21) throw new InvalidDataException($"Expected 21 installed languages, got {entries.Length}");
        Directory.CreateDirectory(output);
        foreach (var entry in entries)
        {
        var language = Path.GetFileNameWithoutExtension(entry.Name);
        var metaEntry = assets.Single(e => e.Name.Equals($"data/loc/{language}-meta.xml", StringComparison.OrdinalIgnoreCase));
        using var dbSource = manager.GetCustomAsset("legacy", entry);
        using var metaSource = manager.GetCustomAsset("legacy", metaEntry);
        var source = Read(dbSource); var metadata = Read(metaSource);
        using var working = new MemoryStream(); working.Write(source); working.Position = 0;
        using var meta = new MemoryStream(metadata);
        using var database = new DbFile(working, meta);
        var before = Snapshot(database);
        var changed = 0;
        var captions = new Dictionary<string, (string Original, string Updated)>();
        foreach (var table in database.GetTables())
        {
            foreach (var row in table.Records.Take(table.NRecords))
            {
                var key = row.GetStringField("stringid");
                if (!edits.TryGetValue(key, out var edit)) continue;
                var originalCaption = row.GetStringField("sourcetext");
                if (originalCaption.Split("200").Length != 2) throw new InvalidDataException($"Unexpected caption in {language}: {originalCaption}");
                var newCaption = originalCaption.Replace("200", edit["top"]!.GetValue<int>().ToString(CultureInfo.InvariantCulture), StringComparison.Ordinal);
                captions.Add(key, (originalCaption, newCaption));
                if (!row.SetField("sourcetext", newCaption)) throw new InvalidDataException("Could not set caption");
                changed++;
            }
        }
        if (changed != 2) throw new InvalidDataException($"Expected two caption rows; found {changed}");
        using var saved = new MemoryStream();
        var dbWriter = new DbWriter(saved, database.Platform);
        database.SaveDb(dbWriter);
        database.ComputeAllCrc(new DbReader(saved, database.Platform), dbWriter);
        var modified = saved.ToArray();
        using var checkData = new MemoryStream(modified);
        using var checkMeta = new MemoryStream(metadata);
        using var check = new DbFile(checkData, checkMeta);
        var after = Snapshot(check);
        if (!before.Keys.Order().SequenceEqual(after.Keys.Order())) throw new InvalidDataException("Table keys changed");
        var differences = new List<string>();
        foreach (var name in before.Keys)
        {
            var a = before[name]; var b = after[name];
            if (a.Rows.Count != b.Rows.Count || a.Columns.Count != b.Columns.Count) throw new InvalidDataException("Table shape changed");
            for (var i = 0; i < a.Rows.Count; i++)
                for (var j = 0; j < a.Columns.Count; j++)
                    if (!Equals(a.Rows[i][j], b.Rows[i][j]))
                    {
                        if (a.Columns[j].ColumnName != "sourcetext" || !captions.TryGetValue(a.Rows[i]["stringid"].ToString()!, out var caption)
                            || a.Rows[i][j].ToString() != caption.Original || b.Rows[i][j].ToString() != caption.Updated)
                            throw new InvalidDataException($"Unrelated change in {name}, row {i}, column {j}");
                        differences.Add($"{name}: {a.Rows[i]["stringid"]}: {a.Rows[i][j]} -> {b.Rows[i][j]}");
                    }
        }
        if (differences.Count != captions.Values.Count(c => c.Original != c.Updated)) throw new InvalidDataException("Unexpected row differences");
        Directory.CreateDirectory(output);
        File.WriteAllBytes(Path.Combine(output, language + ".db"), modified);
        reports.Add(new { language, sourceSha256 = Hash(source), modifiedSha256 = Hash(modified), differences, tables = before.ToDictionary(e => e.Key, e => e.Value.Rows.Count) });
        manager.ModifyCustomAsset("legacy", entry.Name, modified);
        Console.WriteLine($"CAPTION {language}: verified {differences.Count} changed fields");
        }
        File.WriteAllText(Path.Combine(output, "caption-validation.json"), JsonSerializer.Serialize(reports, new JsonSerializerOptions { WriteIndented = true }));
        var settings = new ModSettings
        {
            Title = "Aurora 21 leaderboard tabs", Author = "Aurora 21", Category = "UI", Version = manifest["revision"]!.GetValue<string>(),
            Description = "Changes only Champions and Squad Battles leaderboard captions in all 21 installed languages; preserves translated wording.",
        };
        using var file = File.Create(Path.Combine(output, "aurora21-leaderboards-" + manifest["revision"]!.GetValue<string>() + ".fbmod"));
        using var writer = new FrostbiteModWriter(file, settings);
        writer.WriteProject();
        Console.WriteLine("CAPTION-MOD verified only requested caption fields across all localisation rows; exported fbmod");
    }
    private static Dictionary<string, DataTable> Snapshot(DbFile db) =>
        db.GetTables().ToDictionary(t => t.ToString(), t => t.ConvertToDataTable());
    private static byte[] Read(Stream stream) { using var result = new MemoryStream(); stream.CopyTo(result); return result.ToArray(); }
    private static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
}
